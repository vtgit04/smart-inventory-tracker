import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

from src.preprocessing import load_and_clean_data
from src.classification import abc_classification
from src.restock import low_stock_alerts, auto_restock
from src.forecast import forecast_sales
from src.loss_analysis import loss_analysis
from src.profit import profit_analysis
from src.supplier import recommend_supplier
from src.trend import detect_trends
from src.anomaly import detect_anomalies, detect_price_anomalies, get_inventory_health_score
from src.ai_assistant import ask_inventory_ai, generate_ai_insights

st.set_page_config(
    page_title="Smart Inventory Tracker",
    page_icon="📦",
    layout="wide",
    initial_sidebar_state="expanded"
)

st.markdown("""
<style>
    .stApp { background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%); }
    h1, h2, h3 { color: #ffffff !important; font-weight: 600; }

    section[data-testid="stSidebar"] {
        background: linear-gradient(180deg, #1a1a2e 0%, #16213e 100%);
    }
    section[data-testid="stSidebar"] h2 { color: #667eea !important; }
    section[data-testid="stSidebar"] .stRadio label {
        color: #ffffff !important;
        background: rgba(255,255,255,0.05);
        padding: 12px 15px;
        border-radius: 10px;
        margin: 5px 0;
        border-left: 3px solid transparent;
    }
    section[data-testid="stSidebar"] .stRadio label:hover {
        background: rgba(102,126,234,0.2);
        border-left: 3px solid #667eea;
    }
    section[data-testid="stSidebar"] .stRadio label:has(input:checked) {
        background: linear-gradient(135deg, rgba(102,126,234,0.3) 0%, rgba(118,75,162,0.3) 100%);
        border-left: 3px solid #667eea;
    }

    .stMetric {
        background: linear-gradient(135deg, rgba(255,255,255,0.1) 0%, rgba(255,255,255,0.05) 100%);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255,255,255,0.1);
        padding: 20px;
        border-radius: 16px;
        box-shadow: 0 8px 32px rgba(0,0,0,0.3);
        text-align: center;
    }
    .stMetric label { color: #e0e0e0 !important; font-size: 14px; font-weight: 500; }
    .stMetric [data-testid="stMetricValue"] { color: #00d4ff !important; font-size: 28px; font-weight: 700; }

    .card {
        background: linear-gradient(135deg, rgba(255,255,255,0.1) 0%, rgba(255,255,255,0.05) 100%);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255,255,255,0.1);
        border-radius: 16px;
        padding: 20px;
        box-shadow: 0 8px 32px rgba(0,0,0,0.3);
        margin-bottom: 15px;
    }

    .alert-box {
        padding: 15px 20px;
        border-radius: 12px;
        margin: 10px 0;
        font-weight: 500;
    }
    .alert-critical { background: linear-gradient(135deg, #ff6b6b 0%, #ee5a5a 100%); color: white; border-left: 4px solid #fff; }
    .alert-warning  { background: linear-gradient(135deg, #feca57 0%, #ff9f43 100%); color: #1a1a2e; border-left: 4px solid #fff; }
    .alert-success  { background: linear-gradient(135deg, #26de81 0%, #20bf6b 100%); color: white; border-left: 4px solid #fff; }

    .stButton > button {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        border: none;
        border-radius: 10px;
        padding: 10px 25px;
        font-weight: 600;
        transition: all 0.3s ease;
        box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
    }
    .stButton > button:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 20px rgba(102, 126, 234, 0.6);
    }

    .stTabs [data-baseweb="tab-list"] { gap: 8px; }
    .stTabs [data-baseweb="tab"] {
        background: rgba(255,255,255,0.1);
        border-radius: 10px 10px 0 0;
        padding: 10px 20px;
        color: #ffffff;
    }
    .stTabs [aria-selected="true"] {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important;
        color: white !important;
    }

    .dataframe th { background: rgba(102, 126, 234, 0.3) !important; color: white !important; }
    .dataframe td { color: #e0e0e0 !important; }
    p, span, div { color: #e0e0e0; }
    .streamlit-expanderHeader { color: #e0e0e0 !important; }
</style>
""", unsafe_allow_html=True)

# ── Header ──────────────────────────────────────────────────────────────────
st.markdown("""
<div style="text-align:center; padding: 20px 0;">
    <h1 style="font-size:42px; margin:0; background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);
               -webkit-background-clip:text; -webkit-text-fill-color:transparent; background-clip:text;">
        📦 Smart Inventory Tracker
    </h1>
    <p style="color:#a0a0a0; font-size:18px; margin-top:5px;">
        Track • Analyze • Optimize Your Business
    </p>
</div>
""", unsafe_allow_html=True)

# ── Sidebar ──────────────────────────────────────────────────────────────────
st.sidebar.markdown("""
<div style="text-align:center; padding:15px 0;">
    <h2 style="color:#667eea; margin:0;">📊 Menu</h2>
</div>
""", unsafe_allow_html=True)

menu = st.sidebar.radio(
    "",
    ["🏠 Overview", "📦 Inventory", "📈 Forecasting", "⚙️ Smart Systems", "🔍 Anomaly Detection", "🤖 AI Assistant"],
    index=0,
    label_visibility="collapsed"
)

st.sidebar.markdown("---")

with st.sidebar.expander("⚙️ **Filters**", expanded=True):
    min_qty = st.slider("Minimum Quantity", 0, 100, 0)
    max_price = st.number_input("Maximum Price (₹)", min_value=0.0, value=100000.0, step=100.0)
    selected_categories = st.multiselect(
        "ABC Categories",
        ['A', 'B', 'C'],
        default=['A', 'B', 'C']
    )

st.sidebar.markdown("---")
uploaded_file = st.sidebar.file_uploader("📁 **Upload Inventory CSV**", type=["csv"])

# ── Session state ────────────────────────────────────────────────────────────
if 'inventory' not in st.session_state:
    st.session_state.inventory = None

# ── Data loading ─────────────────────────────────────────────────────────────
if uploaded_file:
    try:
        df_raw = load_and_clean_data(uploaded_file)
        st.session_state.inventory = df_raw
    except ValueError as e:
        st.error(f"❌ Could not load file: {e}")
        st.stop()

df = st.session_state.inventory

if df is not None:
    # ── ABC classification (run once on full data) ────────────────────────
    abc_df_full = abc_classification(df)
    if 'category' not in df.columns:
        df = df.merge(abc_df_full[['product', 'category']], on='product', how='left')

    # ── Apply filters ─────────────────────────────────────────────────────
    df_filtered = df[
        (df['quantity'] >= min_qty) &
        (df['price'] <= max_price) &
        (df['category'].isin(selected_categories))
    ].copy()

    if df_filtered.empty:
        st.warning("⚠️ No products match the current filters. Adjust the sidebar filters to see data.")
        st.stop()

    # ── Pre-compute shared data ───────────────────────────────────────────
    abc_df        = abc_classification(df_filtered)
    alerts        = low_stock_alerts(df_filtered)
    restock_df    = auto_restock(df_filtered)
    loss_df       = loss_analysis(df_filtered)
    profit_df     = profit_analysis(df_filtered)
    supplier_df   = recommend_supplier(df_filtered)
    health_score  = get_inventory_health_score(df_filtered)
    anomalies     = detect_anomalies(df_filtered)   # cached — reused below

    total_products = df_filtered['product'].nunique()
    total_stock    = int(df_filtered['quantity'].sum())
    total_revenue  = int((df_filtered['price'] * df_filtered['quantity']).sum())

    # ── Sidebar quick stats ───────────────────────────────────────────────
    with st.sidebar.expander("📌 Quick Stats"):
        st.markdown(f"""
        <div style="background:rgba(255,255,255,0.05); padding:15px; border-radius:10px;">
            <p style="color:#a0a0a0; margin:5px 0;">📦 Products: <strong style="color:#667eea;">{total_products}</strong></p>
            <p style="color:#a0a0a0; margin:5px 0;">📉 Min Qty filter: <strong style="color:#667eea;">{min_qty}</strong></p>
            <p style="color:#a0a0a0; margin:5px 0;">💰 Max Price filter: <strong style="color:#667eea;">₹{max_price:,.0f}</strong></p>
            <p style="color:#a0a0a0; margin:5px 0;">📂 Categories: <strong style="color:#667eea;">{', '.join(selected_categories)}</strong></p>
            <p style="color:#a0a0a0; margin:5px 0;">❤️ Health: <strong style="color:#667eea;">{health_score}/100</strong></p>
        </div>
        """, unsafe_allow_html=True)

    # ════════════════════════════════════════════════════════════════════════
    # PAGE: OVERVIEW
    # ════════════════════════════════════════════════════════════════════════
    if menu == "🏠 Overview":
        st.markdown("""
        <div style="background:linear-gradient(135deg,#667eea 0%,#764ba2 100%); padding:25px; border-radius:20px; margin-bottom:25px; text-align:center;">
            <h2 style="color:white; margin:0;">📊 Business Dashboard</h2>
            <p style="color:rgba(255,255,255,0.9); margin-top:10px;">Real-time insights into your inventory performance</p>
        </div>
        """, unsafe_allow_html=True)

        kpi1, kpi2, kpi3, kpi4 = st.columns(4)
        kpi1.metric("📦 Products",   total_products)
        kpi2.metric("📊 Total Stock", f"{total_stock:,} units")
        kpi3.metric("💰 Revenue",    f"₹{total_revenue:,}")
        kpi4.metric("❤️ Health",     f"{health_score}/100")

        st.markdown("---")

        health_col1, health_col2 = st.columns([1, 3])
        with health_col1:
            st.markdown("<div class='card' style='text-align:center;'><h3 style='color:#667eea; margin-bottom:15px;'>🏥 Health Score</h3></div>", unsafe_allow_html=True)
            if health_score >= 80:
                color = "linear-gradient(135deg,#26de81 0%,#20bf6b 100%)"
                text_color = "white"
                label = "Excellent!"
                icon = "🌟"
            elif health_score >= 60:
                color = "linear-gradient(135deg,#feca57 0%,#ff9f43 100%)"
                text_color = "#1a1a2e"
                label = "Good"
                icon = "⚠️"
            else:
                color = "linear-gradient(135deg,#ff6b6b 0%,#ee5a5a 100%)"
                text_color = "white"
                label = "Needs Attention"
                icon = "🚨"

            st.markdown(f"""
            <div style="background:{color}; padding:20px; border-radius:15px; text-align:center;">
                <h2 style="color:{text_color}; margin:0;">{icon} {health_score}/100</h2>
                <p style="color:{text_color}; margin:5px 0 0 0;">{label}</p>
            </div>
            """, unsafe_allow_html=True)
            st.progress(health_score / 100)

        with health_col2:
            st.markdown(f"""
            <div class="card">
                <h3 style="color:#667eea; margin-bottom:20px;">📋 Quick Summary</h3>
                <div style="display:flex; flex-wrap:wrap; gap:20px;">
                    <div style="flex:1; min-width:150px;">
                        <p style="color:#a0a0a0; margin:0;">Low Stock Alerts</p>
                        <h2 style="color:#ff6b6b; margin:5px 0;">{len(alerts)}</h2>
                    </div>
                    <div style="flex:1; min-width:150px;">
                        <p style="color:#a0a0a0; margin:0;">Products to Restock</p>
                        <h2 style="color:#feca57; margin:5px 0;">{len(restock_df)}</h2>
                    </div>
                    <div style="flex:1; min-width:150px;">
                        <p style="color:#a0a0a0; margin:0;">Total Est. Profit</p>
                        <h2 style="color:#26de81; margin:5px 0;">₹{int(profit_df['profit'].sum()):,}</h2>
                    </div>
                    <div style="flex:1; min-width:150px;">
                        <p style="color:#a0a0a0; margin:0;">Anomalies Found</p>
                        <h2 style="color:#ff9f43; margin:5px 0;">{len(anomalies)}</h2>
                    </div>
                </div>
            </div>
            """, unsafe_allow_html=True)

        st.markdown("---")

        col1, col2 = st.columns(2)
        with col1:
            st.markdown("<div class='card'><h3 style='color:#667eea; margin-bottom:15px;'>📊 Stock by Product</h3></div>", unsafe_allow_html=True)
            fig_bar = px.bar(
                df_filtered.groupby('product')['quantity'].sum().reset_index(),
                x='product', y='quantity', color='quantity',
                color_continuous_scale='Plasma'
            )
            fig_bar.update_layout(plot_bgcolor='rgba(0,0,0,0)', paper_bgcolor='rgba(0,0,0,0)', font_color='white')
            st.plotly_chart(fig_bar, use_container_width=True)

        with col2:
            st.markdown("<div class='card'><h3 style='color:#667eea; margin-bottom:15px;'>💰 Revenue Distribution</h3></div>", unsafe_allow_html=True)
            rev_df = df_filtered.groupby('product').apply(
                lambda x: (x['price'] * x['quantity']).sum()
            ).reset_index()
            rev_df.columns = ['product', 'revenue']
            fig_pie = px.pie(rev_df, values='revenue', names='product', hole=0.5,
                             color_discrete_sequence=px.colors.qualitative.Pastel)
            fig_pie.update_layout(plot_bgcolor='rgba(0,0,0,0)', paper_bgcolor='rgba(0,0,0,0)', font_color='white')
            st.plotly_chart(fig_pie, use_container_width=True)

        st.markdown("<div class='card'><h3 style='color:#667eea; margin-bottom:15px;'>📈 Price vs Quantity</h3></div>", unsafe_allow_html=True)
        fig_scatter = px.scatter(
            df_filtered, x='quantity', y='price', size='quantity', color='product',
            labels={'quantity': 'Stock Quantity', 'price': 'Price (₹)'}
        )
        fig_scatter.update_layout(plot_bgcolor='rgba(0,0,0,0)', paper_bgcolor='rgba(0,0,0,0)', font_color='white')
        st.plotly_chart(fig_scatter, use_container_width=True)

        with st.expander("📄 View Raw Data"):
            st.dataframe(df_filtered, use_container_width=True, hide_index=True)

    # ════════════════════════════════════════════════════════════════════════
    # PAGE: INVENTORY
    # ════════════════════════════════════════════════════════════════════════
    elif menu == "📦 Inventory":
        st.markdown("""
        <div style="background:linear-gradient(135deg,#f093fb 0%,#f5576c 100%); padding:25px; border-radius:20px; margin-bottom:25px; text-align:center;">
            <h2 style="color:white; margin:0;">📦 Inventory Intelligence</h2>
            <p style="color:rgba(255,255,255,0.9); margin-top:10px;">Analyze, classify, and optimize your stock</p>
        </div>
        """, unsafe_allow_html=True)

        tab1, tab2, tab3 = st.tabs(["📊 ABC Analysis", "⚠️ Low Stock", "📉 Loss Analysis"])

        with tab1:
            st.markdown("<div class='card'><h3 style='color:#667eea;'>ABC Classification</h3><p style='color:#a0a0a0;'>A = top 70% revenue | B = next 20% | C = bottom 10%</p></div>", unsafe_allow_html=True)
            col1, col2 = st.columns([2, 1])
            with col1:
                fig_abc = px.treemap(
                    abc_df, path=['category', 'product'], values='revenue',
                    color='category',
                    color_discrete_map={'A': '#26de81', 'B': '#feca57', 'C': '#ff6b6b'}
                )
                fig_abc.update_layout(plot_bgcolor='rgba(0,0,0,0)', paper_bgcolor='rgba(0,0,0,0)', font_color='white')
                st.plotly_chart(fig_abc, use_container_width=True)
            with col2:
                st.dataframe(abc_df, use_container_width=True, hide_index=True)

        with tab2:
            if alerts.empty:
                st.markdown('<div class="alert-box alert-success" style="text-align:center;">✅ All products are well-stocked!</div>', unsafe_allow_html=True)
            else:
                st.markdown(f'<div style="background:rgba(255,107,107,0.2); padding:15px; border-radius:12px; margin-bottom:20px;"><h3 style="color:#ff6b6b; margin:0;">⚠️ {len(alerts)} Products Need Attention</h3></div>', unsafe_allow_html=True)
                for _, row in alerts.iterrows():
                    alert_class = "alert-critical" if row['quantity'] < 10 else "alert-warning"
                    st.markdown(f'<div class="alert-box {alert_class}">🚨 <strong>{row["product"]}</strong>: Only {int(row["quantity"])} units left (threshold: {int(row["min_stock"])})</div>', unsafe_allow_html=True)
                st.dataframe(alerts, use_container_width=True, hide_index=True)

        with tab3:
            st.markdown("<div class='card'><h3 style='color:#667eea;'>Overstock Loss Estimate</h3><p style='color:#a0a0a0;'>Estimated monthly holding cost for products above 100 units. Assumes 2% holding cost per month.</p></div>", unsafe_allow_html=True)
            if loss_df.empty:
                st.markdown('<div class="alert-box alert-success" style="text-align:center;">✅ No significant overstock detected!</div>', unsafe_allow_html=True)
            else:
                col1, col2 = st.columns(2)
                with col1:
                    fig_loss = px.bar(
                        loss_df, x='product', y='estimated_monthly_loss',
                        color='estimated_monthly_loss', color_continuous_scale='Reds',
                        labels={'estimated_monthly_loss': 'Est. Monthly Loss (₹)'}
                    )
                    fig_loss.update_layout(plot_bgcolor='rgba(0,0,0,0)', paper_bgcolor='rgba(0,0,0,0)', font_color='white')
                    st.plotly_chart(fig_loss, use_container_width=True)
                with col2:
                    st.dataframe(loss_df, use_container_width=True, hide_index=True)

    # ════════════════════════════════════════════════════════════════════════
    # PAGE: FORECASTING
    # ════════════════════════════════════════════════════════════════════════
    elif menu == "📈 Forecasting":
        st.markdown("""
        <div style="background:linear-gradient(135deg,#11998e 0%,#38ef7d 100%); padding:25px; border-radius:20px; margin-bottom:25px; text-align:center;">
            <h2 style="color:white; margin:0;">🔮 Demand Forecasting</h2>
            <p style="color:rgba(255,255,255,0.9); margin-top:10px;">Trend-based predictions for future demand</p>
        </div>
        """, unsafe_allow_html=True)

        has_real_dates = 'date' in df_filtered.columns and df_filtered.groupby('product')['date'].nunique().max() > 1
        if not has_real_dates:
            st.info("ℹ️ Your CSV has one row per product (no date history). Forecasts are based on a flat average. For trend-based forecasts, upload a CSV with multiple dated rows per product.", icon="ℹ️")

        col1, col2 = st.columns([1, 3])
        with col1:
            st.markdown("<div class='card'>", unsafe_allow_html=True)
            product = st.selectbox("🛍️ Select Product", df_filtered['product'].unique())
            forecast_days = st.slider("📅 Forecast Days", 5, 30, 10)
            st.markdown("</div>", unsafe_allow_html=True)

        with col2:
            forecast_df = forecast_sales(df_filtered, product, days=forecast_days)
            fig_forecast = go.Figure()
            fig_forecast.add_trace(go.Scatter(
                x=forecast_df['date'], y=forecast_df['Predicted_Quantity'],
                mode='lines+markers', name='Forecast',
                line=dict(color='#38ef7d', width=3)
            ))
            fig_forecast.update_layout(
                title=f"📈 {product} — Next {forecast_days} Days Forecast",
                xaxis_title="Date", yaxis_title="Predicted Quantity",
                plot_bgcolor='rgba(0,0,0,0)', paper_bgcolor='rgba(0,0,0,0)', font_color='white'
            )
            st.plotly_chart(fig_forecast, use_container_width=True)

        st.markdown("<div class='card'><h3 style='color:#667eea;'>📊 Forecast Data</h3></div>", unsafe_allow_html=True)
        st.dataframe(forecast_df, use_container_width=True, hide_index=True)

        st.markdown("<div class='card'><h3 style='color:#667eea;'>📈 Spike Detection</h3></div>", unsafe_allow_html=True)
        trend_df = detect_trends(df_filtered, product)
        if trend_df.empty:
            st.markdown('<div class="alert-box alert-success" style="text-align:center;">✅ No demand spikes detected for this product</div>', unsafe_allow_html=True)
        else:
            st.markdown('<div class="alert-box alert-warning">⚠️ Demand Spikes Detected!</div>', unsafe_allow_html=True)
            st.dataframe(trend_df, use_container_width=True, hide_index=True)

    # ════════════════════════════════════════════════════════════════════════
    # PAGE: SMART SYSTEMS
    # ════════════════════════════════════════════════════════════════════════
    elif menu == "⚙️ Smart Systems":
        st.markdown("""
        <div style="background:linear-gradient(135deg,#667eea 0%,#764ba2 100%); padding:25px; border-radius:20px; margin-bottom:25px; text-align:center;">
            <h2 style="color:white; margin:0;">⚙️ Smart Automation</h2>
            <p style="color:rgba(255,255,255,0.9); margin-top:10px;">Data-driven recommendations for your business</p>
        </div>
        """, unsafe_allow_html=True)

        tab1, tab2, tab3 = st.tabs(["🔄 Auto-Restock", "🏭 Suppliers", "💰 Profit Analysis"])

        with tab1:
            st.markdown("<div class='card'><h3 style='color:#667eea;'>Restock Recommendations</h3><p style='color:#a0a0a0;'>Based on current stock levels and estimated daily sales. For best results, upload time-series data.</p></div>", unsafe_allow_html=True)
            if restock_df.empty:
                st.markdown('<div class="alert-box alert-success" style="text-align:center;">✅ All products well-stocked!</div>', unsafe_allow_html=True)
            else:
                color_field = 'urgency' if 'urgency' in restock_df.columns else 'recommended_order_qty'
                fig_restock = px.bar(
                    restock_df, x='product', y='recommended_order_qty',
                    color=color_field,
                    color_discrete_map={'Critical': '#ff6b6b', 'High': '#feca57', 'Normal': '#26de81'},
                    labels={'recommended_order_qty': 'Units to Order'}
                )
                fig_restock.update_layout(plot_bgcolor='rgba(0,0,0,0)', paper_bgcolor='rgba(0,0,0,0)', font_color='white')
                st.plotly_chart(fig_restock, use_container_width=True)
                st.dataframe(restock_df, use_container_width=True, hide_index=True)

        with tab2:
            st.markdown("<div class='card'><h3 style='color:#667eea;'>Supplier Recommendations</h3><p style='color:#a0a0a0;'>Scored by volume supplied and average price competitiveness.</p></div>", unsafe_allow_html=True)
            if len(supplier_df) == 1 and supplier_df['supplier'].iloc[0] == 'Default Supplier':
                st.info("ℹ️ Add a 'supplier' column to your CSV to compare suppliers.", icon="ℹ️")
            fig_supplier = px.bar(
                supplier_df.head(10), x='supplier', y='score',
                color='score', color_continuous_scale='Greens',
                labels={'score': 'Supplier Score'}
            )
            fig_supplier.update_layout(plot_bgcolor='rgba(0,0,0,0)', paper_bgcolor='rgba(0,0,0,0)', font_color='white')
            st.plotly_chart(fig_supplier, use_container_width=True)
            st.dataframe(supplier_df, use_container_width=True, hide_index=True)

        with tab3:
            st.markdown("<div class='card'><h3 style='color:#667eea;'>Profit Analysis</h3><p style='color:#a0a0a0;'>Assumes 40% gross margin unless a 'cost_price' column is provided.</p></div>", unsafe_allow_html=True)
            col1, col2 = st.columns(2)
            with col1:
                fig_profit = px.bar(
                    profit_df, x='product', y='profit', color='profit',
                    color_continuous_scale='Blues',
                    labels={'profit': 'Estimated Profit (₹)'}
                )
                fig_profit.update_layout(plot_bgcolor='rgba(0,0,0,0)', paper_bgcolor='rgba(0,0,0,0)', font_color='white')
                st.plotly_chart(fig_profit, use_container_width=True)
            with col2:
                fig_donut = px.pie(
                    profit_df, values='profit', names='product', hole=0.5,
                    color_discrete_sequence=px.colors.qualitative.Set3
                )
                fig_donut.update_layout(plot_bgcolor='rgba(0,0,0,0)', paper_bgcolor='rgba(0,0,0,0)', font_color='white')
                st.plotly_chart(fig_donut, use_container_width=True)
            st.dataframe(profit_df, use_container_width=True, hide_index=True)

    # ════════════════════════════════════════════════════════════════════════
    # PAGE: ANOMALY DETECTION
    # ════════════════════════════════════════════════════════════════════════
    elif menu == "🔍 Anomaly Detection":
        st.markdown("""
        <div style="background:linear-gradient(135deg,#f093fb 0%,#f5576c 100%); padding:25px; border-radius:20px; margin-bottom:25px; text-align:center;">
            <h2 style="color:white; margin:0;">🔍 Anomaly Detection</h2>
            <p style="color:rgba(255,255,255,0.9); margin-top:10px;">ML-powered detection of unusual patterns</p>
        </div>
        """, unsafe_allow_html=True)

        tab1, tab2, tab3 = st.tabs(["📦 Inventory", "💲 Price", "🏥 Health"])

        with tab1:
            st.markdown("<div class='card'><h3 style='color:#667eea;'>🚨 Inventory Anomalies</h3><p style='color:#a0a0a0;'>Detected using Isolation Forest (ML). Requires at least 10 products.</p></div>", unsafe_allow_html=True)
            if anomalies.empty:
                st.markdown('<div class="alert-box alert-success" style="text-align:center;">✅ No anomalies detected!</div>', unsafe_allow_html=True)
            else:
                col1, col2 = st.columns([2, 1])
                with col1:
                    plot_df = anomalies.copy()
                    plot_df['score_size'] = (-plot_df['anomaly_score'] + 0.5).clip(lower=0.1)
                    fig_anomaly = px.scatter(
                        plot_df, x='product', y='quantity',
                        size='score_size', color='severity',
                        color_discrete_map={'High': '#ff6b6b', 'Medium': '#feca57', 'Low': '#26de81'},
                        title="Anomalous Products"
                    )
                    fig_anomaly.update_layout(plot_bgcolor='rgba(0,0,0,0)', paper_bgcolor='rgba(0,0,0,0)', font_color='white')
                    st.plotly_chart(fig_anomaly, use_container_width=True)
                with col2:
                    st.dataframe(anomalies, use_container_width=True, hide_index=True)

        with tab2:
            st.markdown("<div class='card'><h3 style='color:#667eea;'>💲 Price Anomalies</h3><p style='color:#a0a0a0;'>Products priced more than 2 standard deviations from the mean.</p></div>", unsafe_allow_html=True)
            price_anomalies = detect_price_anomalies(df_filtered)
            if price_anomalies.empty:
                st.markdown('<div class="alert-box alert-success" style="text-align:center;">✅ Pricing looks normal!</div>', unsafe_allow_html=True)
            else:
                fig_price = px.bar(
                    price_anomalies, x='product', y='z_score',
                    color='reason',
                    color_discrete_map={'Too expensive': '#ff6b6b', 'Too cheap': '#26de81'}
                )
                fig_price.update_layout(plot_bgcolor='rgba(0,0,0,0)', paper_bgcolor='rgba(0,0,0,0)', font_color='white')
                st.plotly_chart(fig_price, use_container_width=True)
                st.dataframe(price_anomalies, use_container_width=True, hide_index=True)

        with tab3:
            st.markdown("<div class='card'><h3 style='color:#667eea;'>🏥 Inventory Health</h3></div>", unsafe_allow_html=True)
            gauge_col1, gauge_col2, gauge_col3 = st.columns(3)

            with gauge_col1:
                if health_score >= 80:
                    bg = "linear-gradient(135deg,#26de81 0%,#20bf6b 100%)"
                    tc, lbl, ic = "white", "Excellent Health", "❤️"
                elif health_score >= 60:
                    bg = "linear-gradient(135deg,#feca57 0%,#ff9f43 100%)"
                    tc, lbl, ic = "#1a1a2e", "Good Health", "⚠️"
                else:
                    bg = "linear-gradient(135deg,#ff6b6b 0%,#ee5a5a 100%)"
                    tc, lbl, ic = "white", "Needs Attention", "🚨"
                st.markdown(f'<div style="background:{bg}; padding:25px; border-radius:15px; text-align:center;"><h2 style="color:{tc}; margin:0;">{ic} {health_score}/100</h2><p style="color:{tc}; margin:5px 0 0 0;">{lbl}</p></div>', unsafe_allow_html=True)

            with gauge_col2:
                st.markdown(f'<div class="card" style="text-align:center;"><h2 style="color:#ff6b6b;">{len(anomalies)}</h2><p style="color:#a0a0a0;">Anomalies Detected</p></div>', unsafe_allow_html=True)

            with gauge_col3:
                low_stock_count = int((df_filtered['quantity'] < 15).sum()) if 'quantity' in df_filtered.columns else 0
                st.markdown(f'<div class="card" style="text-align:center;"><h2 style="color:#feca57;">{low_stock_count}</h2><p style="color:#a0a0a0;">Low Stock Items</p></div>', unsafe_allow_html=True)

            fig_health = go.Figure(go.Indicator(
                mode="gauge+number",
                value=health_score,
                domain={'x': [0, 1], 'y': [0, 1]},
                gauge={
                    'axis': {'range': [0, 100], 'tickcolor': 'white'},
                    'bar': {'color': "#667eea"},
                    'steps': [
                        {'range': [0, 40],  'color': "#ff6b6b"},
                        {'range': [40, 70], 'color': "#feca57"},
                        {'range': [70, 100],'color': "#26de81"}
                    ]
                }
            ))
            fig_health.update_layout(height=300, plot_bgcolor='rgba(0,0,0,0)', paper_bgcolor='rgba(0,0,0,0)', font_color='white')
            st.plotly_chart(fig_health, use_container_width=True)

    # ════════════════════════════════════════════════════════════════════════
    # PAGE: AI ASSISTANT
    # ════════════════════════════════════════════════════════════════════════
    elif menu == "🤖 AI Assistant":
        st.markdown("""
        <div style="background:linear-gradient(135deg,#667eea 0%,#764ba2 100%); padding:25px; border-radius:20px; margin-bottom:25px; text-align:center;">
            <h2 style="color:white; margin:0;">🤖 AI Inventory Assistant</h2>
            <p style="color:rgba(255,255,255,0.9); margin-top:10px;">Ask anything about your inventory</p>
        </div>
        """, unsafe_allow_html=True)

        # AI Insights
        st.markdown("<div class='card'><h3 style='color:#667eea;'>💡 Auto-Generated Insights</h3></div>", unsafe_allow_html=True)
        insights = generate_ai_insights(df_filtered)
        for insight in insights:
            type_map = {"warning": "alert-warning", "success": "alert-success", "info": "card"}
            css_class = type_map.get(insight["type"], "card")
            st.markdown(f'<div class="alert-box {css_class}"><strong>{insight["title"]}</strong><br>{insight["description"]}</div>', unsafe_allow_html=True)

        st.markdown("---")

        # Chat
        st.markdown("<div class='card'><h3 style='color:#667eea;'>💬 Ask a Question</h3></div>", unsafe_allow_html=True)

        with st.expander("🔑 Groq API Key (optional — enables AI responses)"):
            api_key_input = st.text_input("Enter your Groq API key", type="password", help="Get a free key at console.groq.com")
        
        if 'chat_history' not in st.session_state:
            st.session_state.chat_history = []

        suggested = ["Which products are low on stock?", "What are my top revenue products?", "Which items should I restock?", "Show me overstock items"]
        cols = st.columns(len(suggested))
        for i, suggestion in enumerate(suggested):
            if cols[i].button(suggestion, key=f"suggest_{i}"):
                st.session_state.chat_history.append({"role": "user", "content": suggestion})
                with st.spinner("Thinking..."):
                    response = ask_inventory_ai(suggestion, df_filtered, api_key=api_key_input or None)
                st.session_state.chat_history.append({"role": "assistant", "content": response})

        for msg in st.session_state.chat_history:
            role_color = "#667eea" if msg["role"] == "user" else "#26de81"
            role_label = "You" if msg["role"] == "user" else "AI"
            st.markdown(f'<div class="card" style="border-left:4px solid {role_color};"><strong style="color:{role_color};">{role_label}:</strong><br>{msg["content"]}</div>', unsafe_allow_html=True)

        user_query = st.text_input("Ask about your inventory...", key="chat_input", placeholder="e.g. Which products need restocking?")
        if st.button("Send") and user_query:
            st.session_state.chat_history.append({"role": "user", "content": user_query})
            with st.spinner("Thinking..."):
                response = ask_inventory_ai(user_query, df_filtered, api_key=api_key_input or None)
            st.session_state.chat_history.append({"role": "assistant", "content": response})
            st.rerun()

# ════════════════════════════════════════════════════════════════════════════
# WELCOME SCREEN (no file uploaded)
# ════════════════════════════════════════════════════════════════════════════
else:
    st.markdown("""
    <div style="background:linear-gradient(135deg,#667eea 0%,#764ba2 100%); padding:60px; border-radius:25px; text-align:center; margin:50px 0;">
        <h1 style="color:white; font-size:36px; margin:0;">👋 Welcome!</h1>
        <p style="color:rgba(255,255,255,0.9); font-size:20px; margin-top:15px;">Upload your inventory CSV to get started</p>
        <p style="color:rgba(255,255,255,0.7); margin-top:10px;">📁 Use the upload button in the sidebar →</p>
    </div>

    <div style="display:flex; gap:20px; margin-top:40px; flex-wrap:wrap;">
        <div class="card" style="flex:1; min-width:200px; text-align:center;">
            <h3 style="color:#667eea;">📋 Required CSV Format</h3>
            <p style="color:#a0a0a0;">Minimum required columns:</p>
            <code style="background:rgba(102,126,234,0.2); padding:10px 15px; border-radius:8px; display:inline-block; color:#667eea;">
                product, quantity, price
            </code>
            <p style="color:#a0a0a0; margin-top:10px;">Optional: date, cost_price, supplier, loss</p>
        </div>
        <div class="card" style="flex:1; min-width:200px; text-align:center;">
            <h3 style="color:#667eea;">✨ Features</h3>
            <ul style="color:#e0e0e0; text-align:left; display:inline-block;">
                <li>📊 ABC Classification</li>
                <li>📈 Demand Forecasting</li>
                <li>🔍 ML Anomaly Detection</li>
                <li>💰 Profit & Loss Analysis</li>
                <li>🔄 Smart Restock Alerts</li>
                <li>🤖 AI Chat Assistant</li>
            </ul>
        </div>
        <div class="card" style="flex:1; min-width:200px; text-align:center;">
            <h3 style="color:#667eea;">💡 Pro Tips</h3>
            <ul style="color:#e0e0e0; text-align:left; display:inline-block;">
                <li>Add a <code>date</code> column for better forecasts</li>
                <li>Add <code>cost_price</code> for accurate profit</li>
                <li>Add <code>supplier</code> to compare vendors</li>
                <li>Use sidebar filters to drill down</li>
            </ul>
        </div>
    </div>
    """, unsafe_allow_html=True)
