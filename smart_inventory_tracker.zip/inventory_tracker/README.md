# 📦 Smart Inventory Tracker

A full-stack inventory analytics web app built with Python and Streamlit. Designed for small retail shop owners to track stock, forecast demand, detect anomalies, and get AI-powered business insights — all from a simple CSV upload.

---

## 🚀 Live Demo

👉 [Try it on Streamlit Cloud](#) *(add your link after deploying)*

Upload `sample_inventory.csv` from this repo to explore all features instantly.

---

## ✨ Features

| Feature | Description |
|---|---|
| 📊 **ABC Classification** | Classifies products by revenue contribution (A/B/C) using Pareto analysis |
| 📈 **Demand Forecasting** | Linear trend forecasting per product with configurable horizon |
| 🔍 **Anomaly Detection** | Isolation Forest ML model to flag unusual stock/price patterns |
| ⚠️ **Low Stock Alerts** | Configurable threshold alerts with urgency levels |
| 🔄 **Auto-Restock** | Recommends reorder quantities based on estimated daily sales |
| 📉 **Loss Analysis** | Estimates monthly holding cost for overstocked products |
| 💰 **Profit Analysis** | Per-product profit breakdown (uses cost_price if available, else 40% margin) |
| 🏭 **Supplier Scoring** | Ranks suppliers by volume and price competitiveness |
| 🤖 **AI Chat Assistant** | Natural language Q&A via Groq API (llama-3.1-8b), with smart fallback |

---

## 🛠️ Tech Stack

- **Frontend:** Streamlit, Plotly
- **Data Processing:** Pandas, NumPy
- **Machine Learning:** scikit-learn (Isolation Forest, StandardScaler)
- **AI:** Groq API (LLaMA 3.1 8B) with rule-based fallback
- **Language:** Python 3.10+

---

## 📁 Project Structure

```
smart-inventory-tracker/
├── app.py                  # Main Streamlit application
├── src/
│   ├── preprocessing.py    # CSV loading, cleaning, validation
│   ├── classification.py   # ABC (Pareto) classification
│   ├── restock.py          # Low stock alerts + restock recommendations
│   ├── forecast.py         # Demand forecasting (linear trend)
│   ├── anomaly.py          # Isolation Forest anomaly detection
│   ├── loss_analysis.py    # Overstock holding cost estimation
│   ├── profit.py           # Profit margin analysis
│   ├── supplier.py         # Supplier scoring and ranking
│   ├── trend.py            # Demand spike detection
│   └── ai_assistant.py     # Groq AI chat + fallback responses
├── sample_inventory.csv    # Demo data (30 products, Indian retail)
└── requirements.txt
```

---

## ⚡ Getting Started

### 1. Clone the repo
```bash
git clone https://github.com/yourusername/smart-inventory-tracker.git
cd smart-inventory-tracker
```

### 2. Install dependencies
```bash
pip install -r requirements.txt
```

### 3. Run the app
```bash
streamlit run app.py
```

### 4. Upload your CSV

Minimum required columns:
```
product, quantity, price
```

Optional columns that unlock more features:
```
date        → enables trend forecasting
cost_price  → enables accurate profit calculation
supplier    → enables supplier comparison
```

---

## 🤖 AI Assistant Setup (Optional)

The AI assistant works in two modes:

- **With Groq API key:** Full LLaMA 3.1 responses. Get a free key at [console.groq.com](https://console.groq.com)
- **Without API key:** Built-in rule-based responses (still useful!)

To use the AI assistant, either:
- Enter your key in the app's AI Assistant page, or
- Set the environment variable: `export GROQ_API_KEY=your_key_here`

---

## 📊 Sample Data

The included `sample_inventory.csv` has 30 products across categories like groceries, spices, FMCG, and stationery — representative of a small Indian kirana store.

---

## 🧠 Design Decisions

**Why Isolation Forest for anomaly detection?**
It's unsupervised (no labelled data needed), handles high-dimensional feature spaces well, and is robust to outliers — ideal for real-world inventory data which is often messy.

**Why linear forecasting instead of ARIMA/Prophet?**
Most small shop CSVs have one row per product, not a rich time series. A linear model degrades gracefully with minimal data, while ARIMA would fail silently or produce misleading results.

**Why a rule-based AI fallback?**
Not every user has a Groq API key. The fallback ensures the assistant is useful out of the box without requiring any setup.

---

## 📄 License

MIT License — free to use, modify, and distribute.
