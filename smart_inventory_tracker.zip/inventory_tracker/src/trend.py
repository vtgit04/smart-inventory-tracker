import pandas as pd


def detect_trends(df, product):
    product_df = df[df['product'] == product].copy()

    if product_df.empty:
        return pd.DataFrame()

    product_df['date'] = pd.to_datetime(product_df['date'])
    product_df = product_df.sort_values('date').drop_duplicates(subset='date')

    if len(product_df) < 3:
        return pd.DataFrame()

    product_df['rolling_avg'] = product_df['quantity'].rolling(window=min(7, len(product_df)), min_periods=1).mean()
    product_df['spike'] = product_df['quantity'] > (product_df['rolling_avg'] * 1.4)

    spikes = product_df[product_df['spike']][['date', 'quantity', 'rolling_avg']].copy()
    spikes['deviation_pct'] = ((spikes['quantity'] - spikes['rolling_avg']) / spikes['rolling_avg'] * 100).round(1)

    return spikes.reset_index(drop=True)
