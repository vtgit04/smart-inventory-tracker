import pandas as pd


def profit_analysis(df, margin_pct=0.40):
    """
    Calculate profit per product.
    If 'cost_price' column exists in data, uses that.
    Otherwise assumes a default gross margin (default 40%).
    """
    df = df.copy()

    if 'cost_price' not in df.columns:
        df['cost_price'] = df['price'] * (1 - margin_pct)

    df['profit'] = (df['price'] - df['cost_price']) * df['quantity']

    result = df.groupby('product').agg(
        total_profit=('profit', 'sum'),
        avg_price=('price', 'mean'),
        total_units=('quantity', 'sum')
    ).reset_index()

    result = result.rename(columns={'total_profit': 'profit'})
    result['margin_pct'] = margin_pct * 100

    return result.sort_values('profit', ascending=False)
