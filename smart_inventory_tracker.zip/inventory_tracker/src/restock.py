import pandas as pd


def low_stock_alerts(df, threshold=10):
    df = df.copy()
    df['min_stock'] = threshold
    alerts = df[df['quantity'] < threshold][['product', 'quantity', 'min_stock']]
    return alerts.drop_duplicates(subset='product').reset_index(drop=True)


def auto_restock(df, lead_time=7, safety_stock=10):
    """
    Generate restock recommendations.

    If a 'date' column with real time-series data exists and there are multiple
    rows per product, daily sales rate is estimated from historical quantity changes.
    Otherwise, a conservative fallback of 10% of current stock per day is used,
    and the UI will note this assumption.
    """
    df = df.copy()
    restock_list = []

    products = df['product'].unique()

    for product in products:
        product_df = df[df['product'] == product].sort_values('date')
        current_stock = int(product_df['quantity'].iloc[-1])

        # Estimate daily sales rate
        if len(product_df) > 1:
            # Use average drop between consecutive rows as a proxy for daily sales
            qty_series = product_df['quantity'].values
            drops = [max(0, qty_series[i] - qty_series[i+1]) for i in range(len(qty_series)-1)]
            avg_daily_sales = sum(drops) / len(drops) if drops else max(1, current_stock * 0.1)
        else:
            # Single row: assume 10% of stock sold per day as a conservative estimate
            avg_daily_sales = max(1, current_stock * 0.1)

        reorder_qty = int((avg_daily_sales * lead_time) + safety_stock - current_stock)

        if reorder_qty > 0:
            if current_stock < 5:
                urgency = "Critical"
            elif current_stock < 15:
                urgency = "High"
            else:
                urgency = "Normal"

            restock_list.append({
                "product": product,
                "current_stock": current_stock,
                "est_daily_sales": round(avg_daily_sales, 1),
                "recommended_order_qty": reorder_qty,
                "urgency": urgency
            })

    return pd.DataFrame(restock_list)
