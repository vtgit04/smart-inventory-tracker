import pandas as pd
import streamlit as st


def load_and_clean_data(file):
    try:
        df = pd.read_csv(file)
    except Exception as e:
        raise ValueError(f"Could not read CSV file: {e}")

    # Standardize column names
    df.columns = df.columns.str.lower().str.strip()

    # Required columns check
    required = {'product', 'quantity', 'price'}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"CSV is missing required columns: {', '.join(missing)}. Required: product, quantity, price")

    # Fill missing values
    df['quantity'] = pd.to_numeric(df['quantity'], errors='coerce').fillna(0)
    df['price'] = pd.to_numeric(df['price'], errors='coerce').fillna(0)

    # Strip whitespace from product names
    df['product'] = df['product'].astype(str).str.strip()

    # Remove rows with empty product names
    df = df[df['product'] != '']

    # Date handling — warn user if fabricating dates
    if 'date' not in df.columns:
        st.warning(
            "⚠️ No 'date' column found in your CSV. "
            "Sequential dates have been generated starting from 2024-01-01. "
            "Forecast charts will not reflect real sales history.",
            icon="⚠️"
        )
        df['date'] = pd.date_range(start='2024-01-01', periods=len(df), freq='D')
    else:
        df['date'] = pd.to_datetime(df['date'], errors='coerce')
        nat_count = df['date'].isna().sum()
        if nat_count > 0:
            st.warning(f"⚠️ {nat_count} rows had unparseable dates and were filled with sequential dates.")
            df['date'] = df['date'].fillna(method='ffill').fillna(pd.Timestamp('2024-01-01'))

    return df
