import pandas as pd


def abc_classification(df):
    df = df.copy()

    df['revenue'] = df['price'] * df['quantity']

    # Aggregate by product in case of duplicate rows
    product_revenue = df.groupby('product')['revenue'].sum().reset_index()
    product_revenue = product_revenue.sort_values(by='revenue', ascending=False)

    total = product_revenue['revenue'].sum()
    if total == 0:
        product_revenue['cum_percentage'] = 0
        product_revenue['category'] = 'C'
        return product_revenue[['product', 'revenue', 'cum_percentage', 'category']]

    product_revenue['cum_percentage'] = product_revenue['revenue'].cumsum() / total * 100

    def classify(p):
        if p <= 70:
            return 'A'
        elif p <= 90:
            return 'B'
        else:
            return 'C'

    product_revenue['category'] = product_revenue['cum_percentage'].apply(classify)

    return product_revenue[['product', 'revenue', 'cum_percentage', 'category']]
