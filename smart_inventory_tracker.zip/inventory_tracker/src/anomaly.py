import pandas as pd
import numpy as np
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler


def detect_anomalies(df, contamination=0.1):
    if df is None or len(df) < 10:
        return pd.DataFrame()

    features = [f for f in ['quantity', 'price'] if f in df.columns]
    if not features:
        return pd.DataFrame()

    try:
        X = df[features].copy().fillna(df[features].median())

        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X)

        model = IsolationForest(contamination=contamination, random_state=42)
        df_copy = df.copy()
        df_copy['anomaly'] = model.fit_predict(X_scaled)
        df_copy['anomaly_score'] = model.decision_function(X_scaled)

        anomalies = df_copy[df_copy['anomaly'] == -1].copy()

        if not anomalies.empty:
            anomalies['severity'] = pd.cut(
                anomalies['anomaly_score'],
                bins=[-np.inf, -0.5, -0.2, 0],
                labels=['High', 'Medium', 'Low']
            ).astype(str)

        cols = [c for c in ['product', 'quantity', 'price', 'anomaly_score', 'severity'] if c in anomalies.columns]
        return anomalies[cols].reset_index(drop=True)

    except Exception:
        return pd.DataFrame()


def detect_price_anomalies(df, threshold=2.0):
    if df is None or 'price' not in df.columns:
        return pd.DataFrame()

    try:
        mean_price = df['price'].mean()
        std_price = df['price'].std()

        if std_price == 0:
            return pd.DataFrame()

        df_copy = df.copy()
        df_copy['z_score'] = abs((df_copy['price'] - mean_price) / std_price)
        anomalies = df_copy[df_copy['z_score'] > threshold].copy()
        anomalies['reason'] = anomalies['price'].apply(
            lambda x: 'Too expensive' if x > mean_price else 'Too cheap'
        )
        cols = [c for c in ['product', 'price', 'z_score', 'reason'] if c in anomalies.columns]
        return anomalies[cols].reset_index(drop=True)

    except Exception:
        return pd.DataFrame()


def detect_quantity_anomalies(df, window=7):
    if df is None or 'quantity' not in df.columns or 'date' not in df.columns:
        return pd.DataFrame()

    try:
        df_copy = df.copy()
        df_copy['date'] = pd.to_datetime(df_copy['date'])
        df_copy = df_copy.sort_values('date')

        df_copy['rolling_mean'] = df_copy.groupby('product')['quantity'].transform(
            lambda x: x.rolling(window=window, min_periods=1).mean()
        )
        df_copy['rolling_std'] = df_copy.groupby('product')['quantity'].transform(
            lambda x: x.rolling(window=window, min_periods=1).std()
        )
        df_copy['z_score'] = abs(
            (df_copy['quantity'] - df_copy['rolling_mean']) / (df_copy['rolling_std'] + 1e-6)
        )

        anomalies = df_copy[df_copy['z_score'] > 2].copy()
        if not anomalies.empty:
            anomalies['change_type'] = anomalies.apply(
                lambda row: 'Spike' if row['quantity'] > row['rolling_mean'] else 'Drop', axis=1
            )
        cols = [c for c in ['date', 'product', 'quantity', 'rolling_mean', 'z_score', 'change_type'] if c in anomalies.columns]
        return anomalies[cols].reset_index(drop=True)

    except Exception:
        return pd.DataFrame()


def get_inventory_health_score(df):
    if df is None or df.empty:
        return 0

    score = 100

    if 'quantity' in df.columns:
        low_stock_ratio = (df['quantity'] < 15).sum() / len(df)
        score -= low_stock_ratio * 30

        overstock_ratio = (df['quantity'] > 100).sum() / len(df)
        score -= overstock_ratio * 10

    if 'price' in df.columns and df['price'].std() > 0:
        cv = df['price'].std() / df['price'].mean()
        if cv < 0.1:
            score -= 10

    anomalies = detect_anomalies(df)
    if not anomalies.empty:
        score -= (len(anomalies) / len(df)) * 25

    return max(0, min(100, round(score, 1)))
