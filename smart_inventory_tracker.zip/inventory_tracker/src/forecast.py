import pandas as pd
import numpy as np
import streamlit as st


@st.cache_data
def forecast_sales(df, product, days=10):
    product_df = df[df['product'] == product].copy()

    product_df['date'] = pd.to_datetime(product_df['date'])
    product_df = product_df.sort_values('date').drop_duplicates(subset='date')

    product_df['day'] = np.arange(len(product_df))

    x = product_df['day'].values
    y = product_df['quantity'].values

    future_dates = pd.date_range(
        product_df['date'].iloc[-1] + pd.Timedelta(days=1), periods=days
    )

    if len(x) < 2:
        return pd.DataFrame({
            "date": future_dates,
            "Predicted_Quantity": [int(y.mean())] * days
        })

    coef = np.polyfit(x, y, 1)
    future_days = np.arange(len(product_df), len(product_df) + days)
    preds = np.maximum(coef[0] * future_days + coef[1], 0)

    return pd.DataFrame({
        "date": future_dates,
        "Predicted_Quantity": preds.astype(int)
    })
