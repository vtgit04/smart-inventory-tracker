import os
import streamlit as st

try:
    from groq import Groq
    GROQ_AVAILABLE = True
except ImportError:
    GROQ_AVAILABLE = False


def get_groq_client(api_key=None):
    if not GROQ_AVAILABLE:
        return None

    key = api_key or os.getenv("GROQ_API_KEY")

    if not key:
        try:
            key = st.secrets["GROQ_API_KEY"]
        except Exception:
            pass

    if key:
        return Groq(api_key=key)
    return None


def generate_inventory_summary(df):
    if df is None or df.empty:
        return "No inventory data available."

    total_products = df['product'].nunique()
    total_stock = int(df['quantity'].sum())
    avg_price = df['price'].mean()
    total_value = (df['price'] * df['quantity']).sum()

    low_stock_items = df[df['quantity'] < 20]['product'].unique() if 'quantity' in df.columns else []

    summary = f"""
Inventory Summary:
- Total Unique Products: {total_products}
- Total Stock Units: {total_stock}
- Average Price: ₹{avg_price:.2f}
- Total Inventory Value: ₹{total_value:.2f}
- Low Stock Items (< 20 units): {len(low_stock_items)} products
- Low Stock Products: {', '.join(low_stock_items[:5]) if len(low_stock_items) > 0 else 'None'}
"""
    return summary


def ask_inventory_ai(user_query, df, api_key=None):
    client = get_groq_client(api_key)

    if not client:
        return generate_fallback_response(user_query, df)

    summary = generate_inventory_summary(df)

    system_prompt = f"""You are an expert inventory management AI assistant helping shop owners analyze their inventory.

Current inventory data:
{summary}

Guidelines:
- Keep responses concise and actionable (under 200 words)
- Use bullet points for recommendations
- If the data doesn't support a claim, say so
- Focus on practical business insights
- Use ₹ for currency (Indian Rupees)
"""

    try:
        chat_completion = client.chat.completions.create(
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_query}
            ],
            model="llama-3.1-8b-instant",
            temperature=0.7,
            max_tokens=500
        )
        return chat_completion.choices[0].message.content
    except Exception:
        return generate_fallback_response(user_query, df)


def generate_fallback_response(user_query, df):
    if df is None or df.empty:
        return "Please upload inventory data first to get insights."

    query_lower = user_query.lower()

    if any(word in query_lower for word in ['low', 'stock', 'alert', 'restock', 'warning']):
        threshold = min(df['quantity'].mean() * 0.5, 15)
        low_stock = df[df['quantity'] < threshold][['product', 'quantity']].sort_values('quantity').head(10)
        if not low_stock.empty:
            items = "\n".join([f"⚠️ {row['product']}: {int(row['quantity'])} units" for _, row in low_stock.iterrows()])
            return f"**Low Stock Items** (below {int(threshold)} units):\n{items}"
        return "✅ All products have healthy stock levels!"

    elif any(word in query_lower for word in ['revenue', 'profit', 'money', 'sales', 'top']):
        df = df.copy()
        df['revenue'] = df['price'] * df['quantity']
        top_products = df.groupby('product')['revenue'].sum().sort_values(ascending=False).head(5)
        return "**Top Revenue Products:**\n" + "\n".join([f"💰 {prod}: ₹{rev:,.2f}" for prod, rev in top_products.items()])

    elif any(word in query_lower for word in ['category', 'group', 'abc']):
        if 'category' in df.columns:
            categories = df.groupby('category')['quantity'].sum().sort_values(ascending=False)
            return "**Stock by Category:**\n" + "\n".join([f"📦 {cat}: {qty} units" for cat, qty in categories.items()])

    total_value = (df['quantity'] * df['price']).sum()
    return (
        f"**Inventory Snapshot:**\n"
        f"- {df['product'].nunique()} unique products\n"
        f"- {int(df['quantity'].sum())} total units in stock\n"
        f"- Average quantity per product: {df['quantity'].mean():.1f}\n"
        f"- Total inventory value: ₹{total_value:,.2f}"
    )


def generate_ai_insights(df):
    if df is None or df.empty:
        return [{"type": "info", "title": "📂 No Data", "description": "Upload inventory data to generate AI insights."}]

    insights = []

    if 'quantity' in df.columns:
        low_stock = df[df['quantity'] < 15]
        if not low_stock.empty:
            insights.append({
                "type": "warning",
                "title": "🚨 Restock Required",
                "description": f"{len(low_stock)} products are running low. Prioritize: {', '.join(low_stock['product'].head(3).tolist())}"
            })

        overstock = df[df['quantity'] > df['quantity'].mean() * 2]
        if not overstock.empty:
            insights.append({
                "type": "info",
                "title": "📦 Overstock Alert",
                "description": f"{len(overstock)} products have excess stock. Consider promotions for: {', '.join(overstock['product'].head(3).tolist())}"
            })

    if 'price' in df.columns and 'quantity' in df.columns:
        df = df.copy()
        df['revenue'] = df['price'] * df['quantity']
        top_product = df.groupby('product')['revenue'].sum().idxmax()
        max_revenue = df.groupby('product')['revenue'].sum().max()
        insights.append({
            "type": "success",
            "title": "💡 Best Performer",
            "description": f"{top_product} generated the highest revenue at ₹{max_revenue:,.2f}"
        })

    if len(df) > 10:
        insights.append({
            "type": "success",
            "title": "✅ Data Quality",
            "description": f"Your inventory has {len(df)} records across {df['product'].nunique()} products — enough for reliable analysis."
        })

    return insights if insights else [{"type": "info", "title": "ℹ️ All Clear", "description": "No significant issues detected in your inventory."}]
