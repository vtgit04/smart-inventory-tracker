import pandas as pd


def recommend_supplier(df):
    df = df.copy()

    if 'supplier' not in df.columns:
        df['supplier'] = "Default Supplier"

    supplier_stats = df.groupby('supplier').agg(
        avg_price=('price', 'mean'),
        total_units=('quantity', 'sum'),
        product_count=('product', 'nunique')
    ).reset_index()

    max_qty = supplier_stats['total_units'].max()
    max_price = supplier_stats['avg_price'].max()

    if max_qty == 0:
        supplier_stats['score'] = 0
    else:
        supplier_stats['score'] = (
            (supplier_stats['total_units'] / max_qty) * 0.6 +
            ((max_price - supplier_stats['avg_price']) / (max_price + 1e-6)) * 0.4
        ).round(3)

    return supplier_stats.sort_values('score', ascending=False).reset_index(drop=True)
