import pandas as pd


def loss_analysis(df, overstock_threshold=100, holding_cost_pct=0.02):
    """
    Estimate potential losses from overstocked products.

    Logic: products with quantity above the overstock_threshold are assumed
    to incur a monthly holding cost (default 2% of inventory value per month).
    If a real 'loss' column exists, that is used directly instead.
    """
    df = df.copy()

    if 'loss' in df.columns and df['loss'].sum() > 0:
        # Use real loss data if provided
        return df.groupby('product')['loss'].sum().reset_index().sort_values('loss', ascending=False)

    # Estimate holding cost loss for overstocked items
    df['inventory_value'] = df['price'] * df['quantity']
    df['excess_qty'] = (df['quantity'] - overstock_threshold).clip(lower=0)
    df['excess_value'] = df['price'] * df['excess_qty']
    df['estimated_monthly_loss'] = df['excess_value'] * holding_cost_pct

    result = df.groupby('product').agg(
        excess_units=('excess_qty', 'sum'),
        excess_inventory_value=('excess_value', 'sum'),
        estimated_monthly_loss=('estimated_monthly_loss', 'sum')
    ).reset_index()

    return result[result['excess_units'] > 0].sort_values('estimated_monthly_loss', ascending=False).reset_index(drop=True)
